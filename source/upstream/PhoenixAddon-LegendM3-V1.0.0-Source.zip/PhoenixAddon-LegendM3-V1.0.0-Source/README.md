PhoenixAddon-LegendM3 V1.0.0 源码。构建入口及所需目标 ROM/供体输入见源码内构建脚本与技术说明；不包含签名私钥。
