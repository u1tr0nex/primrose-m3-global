"""Prepare the private native dependency from official ShadowHook source."""
from build_aec_hook import main


if __name__ == "__main__":
    main()
