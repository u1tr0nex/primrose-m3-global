#pragma once
#include "mivi14.h"
int m3_aux_publish(const m3::mivi14::ImageParams& input);
